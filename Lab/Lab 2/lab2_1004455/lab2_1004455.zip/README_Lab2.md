# 1004455 Networks Lab 2
# How to run
The project is a modified version of the github repository of the lab instructions.
please run the following to build and run the docker

```
docker-compose build
docker-compose up
```

Test cases have been written in `test.http`.
I used visual studio code to run these with the REST extension. I have written comments in the test file on running the tests.