#!/bin/bash
# install script for 50.012 exercise 6

sudo apt-get install dnsmasq #isc-dhcp-server #netstat-nat

#echo 'INTERFACES="srv1-eth0"' | sudo tee /etc/default/isc-dhcp-server
#sudo cp dhcpd.conf /etc/dhcp/
